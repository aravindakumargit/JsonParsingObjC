//
//  ViewController.m
//  JsonParsingExp
//
//  Created by Aravindakumar Arunachalam on 27/09/17.
//  Copyright © 2017 Aravindakumar Arunachalam. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self jsonArrayLikeStuff];
    [self jsonWithDictionaryStr];
    // Do any additional setup after loading the view, typically from a nib.
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)jsonWithDictionaryStr{
    NSMutableArray *nameArr=[[NSMutableArray alloc]init];
    NSMutableArray *mobileArr=[[NSMutableArray alloc]init];
    NSDictionary *phone;
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:@"http://api.androidhive.info/contacts/"]];
    [request setHTTPMethod:@"GET"];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSString *requestReply = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
        NSDictionary* json = [NSJSONSerialization JSONObjectWithData:data
                                                             options:kNilOptions
                                                               error:&error];
        
        NSLog(@"Request reply: %@", json);
        NSArray *contactArr = [[NSArray alloc]initWithArray:[json objectForKey:@"contacts"]];
        for(int i=0;i<contactArr.count;i++){
            NSString *Name =[[contactArr objectAtIndex:i]objectForKey:@"name"];
            [nameArr addObject:Name];
            NSDictionary *Phone =[[contactArr objectAtIndex:i]objectForKey:@"phone"];
            [mobileArr addObject:[Phone objectForKey:@"mobile"] ];
            
        }
        NSLog(@"nameis %@",nameArr);
        NSLog(@"mobileis %@",mobileArr);
    }] resume];
  
}



-(void)jsonArrayLikeStuff{
    NSMutableArray *fromArr=[[NSMutableArray alloc]init];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setURL:[NSURL URLWithString:@"https://api.androidhive.info/json/inbox.json"]];
    [request setHTTPMethod:@"GET"];
    
    NSURLSession *session = [NSURLSession sessionWithConfiguration:[NSURLSessionConfiguration defaultSessionConfiguration]];
    [[session dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSString *requestReply = [[NSString alloc] initWithData:data encoding:NSASCIIStringEncoding];
        //NSError* error;
        NSArray* jsonArr = [NSJSONSerialization JSONObjectWithData:data
                                                             options:kNilOptions
                                                               error:&error];
        
        NSLog(@"Request reply: %@", jsonArr);
    
        for(int i=0;i<jsonArr.count;i++){
            NSString *from =[[jsonArr objectAtIndex:i]objectForKey:@"from"];
            [fromArr addObject:from];
        }
        NSLog(@"nameis %@",fromArr);
    }] resume];
}

@end
